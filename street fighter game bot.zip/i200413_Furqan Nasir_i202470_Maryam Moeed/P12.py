#!/usr/bin/env python
# coding: utf-8

# In[1]:


import tensorflow as tf
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler


# In[2]:


d2 = pd.read_csv('data.csv')
d1=d2
d2


# In[3]:


d1 = d1.assign(x_Change=lambda x: abs(x['player1_x_coord'] - x['player2_x_coord']), y_Change=lambda x: abs(x['player1_y_coord'] - x['player2_y_coord']))


# In[4]:


d1=d1.drop(['has_round_started','is_round_over','player1_is_jumping','player1_is_crouching','player2_health','player1_id','player1_move_id','player2_move_id','player2_id','player1_is_player_in_move','player2_is_player_in_move','fight result','player1_button_start','player1_button_select', 'player2_button_start','player2_button_select','player1_button_right','player1_button_left','player1_button_up','player1_button_down','player1_button_L','player1_button_R','player1_button_X','player1_button_Y','player1_button_A','player1_button_B'],axis=1)


# In[5]:


dropColumns=['player2_move_id','player1_move_id','player2_is_player_in_move','player1_is_player_in_move','player2_is_crouching','player1_is_crouching','player2_is_jumping','player1_is_jumping','is_round_over','Timer','fight result','has_round_started','player1_id','player1_button_select','player1_button_start','player2_id','player2_button_select','player2_button_start']
d2=d2.drop(dropColumns,axis=1)


# In[6]:


d2


# In[7]:


columns = d2.columns
totalCols = len(columns)

columnsF = columns[:totalCols // 2]
columnsS = columns[totalCols // 2:]

PlayerOne = d2[columnsF]
PlayerTwo = d2[columnsS]


# In[8]:


PlayerOne


# In[9]:


PlayerTwo


# In[10]:


# Select the four columns you want to combine
columns_to_combine = ['player1_button_up', 'player1_button_down', 'player1_button_right', 'player1_button_left']

# Concatenate the values from the four columns into a new column
PlayerOne['OneMove'] = PlayerOne[columns_to_combine].apply(lambda row: ''.join(row.values.astype(str)), axis=1)


# In[11]:


PlayerOne


# In[12]:


# Select the four columns you want to combine
columns_to_combine = ['player1_button_up', 'player1_button_down', 'player1_button_right', 'player1_button_left']

# Concatenate the values from the four columns into a new column
PlayerTwo['TwoMove'] = PlayerOne[columns_to_combine].apply(lambda row: ''.join(row.values.astype(str)), axis=1)


# In[13]:


PlayerTwo


# In[14]:


cols1 = ['player1_button_Y', 'player1_button_B', 'player1_button_X',
                'player1_button_A', 'player1_button_L', 'player1_button_R']
PlayerOne['OneAtk'] = ""
for col in cols1:
    PlayerOne['OneAtk'] += PlayerOne[col].astype(str)


# In[15]:


PlayerOne


# In[16]:


cols2 = ['player2_button_Y', 'player2_button_B', 'player2_button_X',
                'player2_button_A', 'player2_button_L', 'player2_button_R']
PlayerTwo['TwoAtk'] = ""
for col in cols2:
    PlayerTwo['TwoAtk'] += PlayerTwo[col].astype(str)


# In[17]:


PlayerTwo


# In[18]:


PlayerOne['OneMoveDec'] = PlayerOne['OneMove'].apply(lambda x: int(x, 2))
PlayerOne['OneAtkDec'] = PlayerOne['OneAtk'].apply(lambda x: int(x, 2))


# In[19]:


PlayerTwo['TwoMoveDec'] = PlayerTwo['TwoMove'].apply(lambda x: int(x, 2))
PlayerTwo['TwoAtkDec'] = PlayerTwo['TwoAtk'].apply(lambda x: int(x, 2))


# In[20]:


PlayerOne.info()


# In[21]:


PlayerTwo.info()


# In[22]:


display(PlayerOne)


# In[23]:


display(PlayerTwo)


# In[24]:


FinalOne = PlayerOne


# In[25]:


FinalTwo = PlayerTwo


# In[26]:


Player = pd.concat([FinalOne, FinalTwo], axis=1)


# In[27]:


def convert_to_binary(column):
    binary_values = column.apply(lambda x: bin(x)[2:])
    return binary_values

for col in Player.columns:
    Player[col+'B'] = convert_to_binary(Player[col])


# In[28]:


d1


# In[29]:


d1.info()


# In[30]:


DropColumnsX = [
    'player2_button_up', 
    'player2_button_down', 
    'player2_button_left', 
    'player2_button_right',
    'player2_button_L', 
    'player2_button_R', 
    'player2_button_A', 
    'player2_button_X',
    'player2_button_B', 
    'player2_button_Y',
]

ColumnsY = [
    'player2_button_up', 
    'player2_button_down', 
    'player2_button_left', 
    'player2_button_right',
    'player2_button_L', 
    'player2_button_R', 
    'player2_button_A', 
    'player2_button_X',
    'player2_button_B', 
    'player2_button_Y'
]

X = d1.drop(DropColumnsX, axis=1)
Y = d1[ColumnsY]

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.2, random_state=42)

storeSc = StandardScaler()
X_train = storeSc.fit_transform(X_train)
X_test = storeSc.transform(X_test)


# In[33]:


IS = (X_train.shape[1],)

model_history = tf.keras.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=IS),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(Y_train.shape[1], activation='sigmoid')
])


# In[34]:


model_history.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])
model_history.fit(X_train, Y_train, epochs=25, batch_size=32, validation_data=(X_test, Y_test))


# In[35]:


loss, acc = model_history.evaluate(X_test, Y_test)


# In[36]:


print('Loss:', loss)
print('Accuracy:', acc)


# In[37]:


prd = model_history.predict(X_test)


# In[38]:


model_history.save('BotFile.h5')


# In[39]:


prdBT = (prd > 0.1)

# Convert boolean values to True/False
prdBT = prdBT.astype(bool)

# Print the predicted boolean values
for i in prdBT:
    print(i)


# In[40]:


import joblib

scFN = 'scalarFile.save'
joblib.dump(storeSc, scFN)


# In[41]:


from sklearn.ensemble import RandomForestClassifier
model = RandomForestClassifier(n_estimators=500)

# Fit the model to the training data
model.fit(X_train, Y_train)

# Evaluate the model on the test data
accuracy = model.score(X_test, Y_test)
print("Accuracy:", accuracy)


# In[ ]:




